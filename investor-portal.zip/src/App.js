import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";

function Navbar() {
  return (
    <nav className="bg-blue-900 text-white p-4 flex justify-between">
      <div className="font-bold">Investor Portal</div>
      <div className="space-x-4">
        <Link to="/">Home</Link>
        <Link to="/why">Why Uzbekistan?</Link>
        <Link to="/news">News</Link>
        <Link to="/services">Services</Link>
        <Link to="/projects">Ongoing Projects</Link>
        <Link to="/investors">For Investors</Link>
        <Link to="/tender">Tender</Link>
        <Link to="/subsidiya">Subsidiya</Link>
        <Link to="/login">Log In</Link>
        <Link to="/signup">Sign Up</Link>
      </div>
    </nav>
  );
}

function Home() {
  return (
    <div className="p-6">
      <div className="bg-yellow-300 p-10 rounded-lg shadow-md text-center">
        <h1 className="text-3xl font-bold">Ongoing Projects</h1>
        <p className="mt-2">Explore investment opportunities in Uzbekistan.</p>
      </div>
      <div className="mt-6">
        <h2 className="text-xl font-bold">FAQ</h2>
        <p>Here will be frequently asked questions.</p>
      </div>
      <div className="mt-6">
        <h2 className="text-xl font-bold">Last News</h2>
        <p>Latest updates from investment sector.</p>
      </div>
    </div>
  );
}

function Login() {
  return (
    <div className="p-6 max-w-md mx-auto">
      <h2 className="text-2xl font-bold mb-4">Log In</h2>
      <form className="space-y-4">
        <input className="w-full p-2 border rounded" placeholder="PINFL / STIR" />
        <input className="w-full p-2 border rounded" type="password" placeholder="Password" />
        <button className="bg-blue-600 text-white px-4 py-2 rounded">Log In</button>
      </form>
    </div>
  );
}

function SignUp() {
  return (
    <div className="p-6 max-w-md mx-auto">
      <h2 className="text-2xl font-bold mb-4">Sign Up</h2>
      <form className="space-y-4">
        <input className="w-full p-2 border rounded" placeholder="PINFL / STIR" />
        <input className="w-full p-2 border rounded" type="password" placeholder="Password" />
        <input className="w-full p-2 border rounded" type="password" placeholder="Repeat Password" />
        <button className="bg-green-600 text-white px-4 py-2 rounded">Sign Up</button>
      </form>
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<SignUp />} />
      </Routes>
    </Router>
  );
}
